//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Juan Manuel Licea Guajardo on 1/8/19.
//  Copyright © 2019 Juan Manuel Licea Guajardo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labPais: UILabel!
    @IBOutlet weak var labHamburguesa: UILabel!
    let paises = ColeccionDePaises()
    let hamburguesas = ColeccionDeHamburguesas()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnQuiero() {
        labPais.text = paises.obtenPais();
        labHamburguesa.text = hamburguesas.obtenHamburguesa();
    }
    
}


//
//  Datos.swift
//  Hamburguesas
//
//  Created by Juan Manuel Licea Guajardo on 1/8/19.
//  Copyright © 2019 Juan Manuel Licea Guajardo. All rights reserved.
//

import Foundation

class ColeccionDePaises {
    let paises = ["Mexico","E.U.A.","Canada","Brazil","Costa Rica","Argentina","Peru","Cuba","Guatemala","Venezuela","Honduras","Chile","Uruguay","Italia","Amsterdam","Croacia","Francia","Rusia","Egipto","Nigeria"]
    
    func obtenPais() ->String {
        let pais = Int(arc4random()) % paises.count
        return paises[pais]
    }
}

class ColeccionDeHamburguesas {
    let hamburguesas = ["Clasica","Hawaiana","Nortena","Texana","Tres quesos","Especial","Vegetariana","Light","Arrachera","Trompo","Mixta","Doble Carne","Bacon","Bacon Cheese","Al carbon","A la plancha","Al horno","De pollo","De pescado","De camaron"]
    
    func obtenHamburguesa()->String {
        let hamburguesa = Int(arc4random()) % hamburguesas.count
        return hamburguesas[hamburguesa]
        
    }
}

import UIKit

//CADA NUMERO ENTRARA EN TODOS LOS CONDICIONANTES
for i in 0...100{
    //Condicionante para definir si es divisible entre 5
    if i % 5 == 0{
        print("\(i)" + "Bingo!!!")
    }
    
    //Condicionante para definir si es numero par o impar
    if i % 2 == 0{
        print("\(i)" + "par!!!")
    }else{
        print("\(i)" + "impar!!!")
    }
    
    //Condicionantes para definir si esta dentro del rango 30-40
    if i >= 30 && i <= 40{
        print("\(i)" + "Viva Swift!!!")
    }
}

